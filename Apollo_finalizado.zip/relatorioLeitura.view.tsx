import React from 'react';
import {
  View,
  Text,
  ScrollView,
  ActivityIndicator,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../../navigation/AppNavigator';
import { useRelatorioLeitura } from './useRelatorioLeitura';
import { styles } from './relatorioLeitura.styles';
import { colors } from '../../theme/colors';

// ============================================================
// TIPAGEM DA NAVEGAÇÃO
// ============================================================
type NavigationProp = StackNavigationProp<RootStackParamList, 'RelatorioLeitura'>;

// ============================================================
// VIEW: RelatorioLeituraScreen
// Exibe os dados consolidados de leitura do usuário.
// View pura — sem lógica, apenas renderização (Clean Architecture).
// ============================================================
export default function RelatorioLeituraScreen() {
  const navigation = useNavigation<NavigationProp>();
  const {
    dados,
    isLoading,
    error,
    meta,
    editandoMeta,
    setEditandoMeta,
    novaMeta,
    setNovaMeta,
    salvarMeta,
  } = useRelatorioLeitura();

  // ============================================================
  // RENDERIZAÇÃO CONDICIONAL
  // ============================================================

  // 1. Enquanto carrega, exibe spinner
  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <ActivityIndicator size="large" color={colors.primary} />
      </SafeAreaView>
    );
  }

  // 2. Se houve erro
  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <Text style={styles.errorText}>{error}</Text>
      </SafeAreaView>
    );
  }

  // 3. Se o usuário nunca registrou leituras
  if (!dados || dados.total_paginas_geral === 0) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.emptyContainer}>
          <Text style={styles.titulo}>📚 Relatório de Leitura</Text>
          <Text style={styles.emptyText}>
            Você ainda não registrou nenhuma leitura.
          </Text>
          <Text style={styles.emptySubtext}>
            Comece agora mesmo e acompanhe seu progresso!
          </Text>
          <TouchableOpacity
            style={styles.botaoIrLer}
            onPress={() => navigation.navigate('Ler')}
          >
            <Text style={styles.botaoIrLerText}>📖 Ir para Leitura</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ============================================================
  // RENDERIZAÇÃO PRINCIPAL (com dados)
  // ============================================================

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* ============================================================
            BOTÃO: Voltar para Hábitos (padrão Apollo)
            ============================================================ */}
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.backButton}
        >
          <Text style={styles.backButtonText}>← Voltar para a tela anterior</Text>
        </TouchableOpacity>

        {/* ============================================================
            CABEÇALHO
            ============================================================ */}
        <Text style={styles.titulo}>📚 Relatório de Leitura</Text>
        <Text style={styles.subtitulo}>Análise do seu progresso como leitor</Text>

        {/* ============================================================
            CARDS DE MÉTRICAS (grid 2 colunas)
            ============================================================ */}
        <View style={styles.grid}>

          <View style={styles.card}>
            <Text style={styles.cardIcone}>📖</Text>
            <Text style={styles.cardValor}>{dados.total_paginas_geral}</Text>
            <Text style={styles.cardLabel}>Total de páginas lidas</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardIcone}>📚</Text>
            <Text style={styles.cardValor}>{dados.total_livros}</Text>
            <Text style={styles.cardLabel}>Livros registrados</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardIcone}>📅</Text>
            <Text style={styles.cardValor}>{dados.total_sessoes_mes}</Text>
            <Text style={styles.cardLabel}>Sessões este mês</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.cardIcone}>📊</Text>
            <Text style={styles.cardValor}>
              {dados.media_por_sessao.toFixed(1)}
            </Text>
            <Text style={styles.cardLabel}>Média págs/sessão</Text>
          </View>

        </View>

        {/* ============================================================
            BARRA DE PROGRESSO DA META MENSAL (com edição)
            ============================================================ */}
        <View style={styles.metaContainer}>
          <View style={styles.metaHeader}>
            <Text style={styles.metaTitulo}>🎯 Meta Mensal</Text>
            <Text style={styles.metaPercentual}>{dados.percentual_meta}%</Text>
          </View>

          <View style={styles.barraFundo}>
            <View
              style={[
                styles.barraPreenchida,
                { width: `${dados.percentual_meta}%` },
              ]}
            />
          </View>

          <View style={styles.metaFooter}>
            <Text style={styles.metaTexto}>
              {dados.total_paginas_mes} / {dados.meta_mensal} páginas este mês
            </Text>

            {/* Botão para editar a meta */}
            {!editandoMeta ? (
              <TouchableOpacity
                style={styles.editarMetaButton}
                onPress={() => setEditandoMeta(true)}
              >
                <Text style={styles.editarMetaButtonText}>✎ Editar Meta</Text>
              </TouchableOpacity>
            ) : (
              <View style={styles.editarMetaInputContainer}>
                <TextInput
                  style={styles.editarMetaInput}
                  keyboardType="numeric"
                  value={novaMeta}
                  onChangeText={setNovaMeta}
                  placeholder="Nova meta"
                  placeholderTextColor="#9CA3AF"
                />
                <TouchableOpacity
                  style={styles.editarMetaSalvar}
                  onPress={salvarMeta}
                >
                  <Text style={styles.editarMetaSalvarText}>Salvar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.editarMetaCancelar}
                  onPress={() => {
                    setEditandoMeta(false);
                    setNovaMeta(String(meta));
                  }}
                >
                  <Text style={styles.editarMetaCancelarText}>Cancelar</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        </View>

        {/* ============================================================
            ÚLTIMO LIVRO LIDO
            ============================================================ */}
        {dados.ultimo_livro && (
          <View style={styles.ultimoLivro}>
            <Text style={styles.ultimoLivroTitulo}>📖 Último livro lido</Text>
            <Text style={styles.ultimoLivroNome}>
              {dados.ultimo_livro.nome}
            </Text>
            <Text style={styles.ultimoLivroAutor}>
              - {dados.ultimo_livro.autor}
            </Text>
            <Text style={styles.ultimoLivroPaginas}>
              - {dados.ultimo_livro.paginas_ultima_sessao} páginas na última sessão
            </Text>
          </View>
        )}

      </ScrollView>
    </SafeAreaView>
  );
}