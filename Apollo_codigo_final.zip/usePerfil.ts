// ============================================================
// IMPORTAÇÕES
// ============================================================

import { useState, useEffect } from 'react';
import { api } from '../../services/api';
import { Alert } from 'react-native';

// ============================================================
// IMAGENS DAS CONQUISTAS E HÁBITOS (MANTIDAS)
// ============================================================

// @ts-ignore
import imgLeitura from '../../../assets/leitura.png';
// @ts-ignore
import imgMusculacao from '../../../assets/musculacao.png';
// @ts-ignore
import imgAgua from '../../../assets/agua.png';
// @ts-ignore
import imgCorrendo from '../../../assets/correndo.png';

// Conquistas
// @ts-ignore
import imgDezDias from '../../../assets/dezDias.png';
// @ts-ignore
import imgCinquentaDias from '../../../assets/cinquentaDias.png';
// @ts-ignore
import imgCemDias from '../../../assets/cemDias.png';

// ============================================================
// INTERFACES (tipagem dos dados)
// ============================================================

// Dados principais do perfil (nome, email, XP, nível)
interface PerfilData {
  nome: string;
  email: string;
  avatar_url?: string;
  total_xp: number;
  nivel: string;
  xp_proximo_nivel: number | null;
}

// Dados pessoais (data de nascimento, peso, altura)
interface DadosPessoais {
  data_nascimento: string;
  peso: string;
  altura: string;
}

// Hábito recente (vem do backend)
interface HabitoRecente {
  id: number;
  label: string;
  image: string | null;
}

// ============================================================
// HOOK PRINCIPAL: usePerfil
// ============================================================
export const usePerfil = () => {
  // ---- ESTADOS ----
  const [perfil, setPerfil] = useState<PerfilData | null>(null);
  const [dadosPessoais, setDadosPessoais] = useState<DadosPessoais>({
    data_nascimento: '',
    peso: '',
    altura: '',
  });
  const [habitosRecentes, setHabitosRecentes] = useState<HabitoRecente[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // ============================================================
  // FUNÇÃO PRINCIPAL: carregarDados
  // Busca todas as informações do perfil em paralelo
  // ============================================================
  const carregarDados = async () => {
    setIsLoading(true);
    setError(null);
    try {
      // 1. Busca dados do perfil (nome, email, avatar, e os novos campos)
      //    e saldo de XP (total, nível, próximo nível)
      const [perfilResponse, xpResponse] = await Promise.all([
        api.get('/usuarios/perfil'),
        api.get('/xp/saldo')
      ]);

      // Atualiza os dados principais do perfil
      setPerfil({
        nome: perfilResponse.data.nome || 'Usuário',
        email: perfilResponse.data.email || '',
        avatar_url: perfilResponse.data.avatar_url,
        total_xp: xpResponse.data.total_xp ?? 0,
        nivel: xpResponse.data.nivel_atual || 'Iniciante',
        xp_proximo_nivel: xpResponse.data.xp_proximo_nivel ?? null,
      });

      // 2. Atualiza os dados pessoais (vêm do mesmo perfilResponse)
      setDadosPessoais({
        data_nascimento: perfilResponse.data.data_nascimento || '',
        peso: perfilResponse.data.peso ? String(perfilResponse.data.peso) : '',
        altura: perfilResponse.data.altura ? String(perfilResponse.data.altura) : '',
      });

      // 3. Busca os últimos 4 hábitos registrados pelo usuário
      const habitosRes = await api.get('/usuarios/habitos-recentes');
      
      // Mapeia os hábitos com fallback para imagens locais (caso o backend não retorne ícone)
      const habitosComImagem = habitosRes.data.map((h: any) => ({
        ...h,
        image: h.image || getImagemFallback(h.label)
      }));
      setHabitosRecentes(habitosComImagem);

    } catch (err: any) {
      console.error('Erro ao carregar perfil:', err);
      setError('Não foi possível carregar os dados do perfil.');
      
      // Fallback: dados mínimos para não quebrar a UI
      setPerfil({
        nome: 'Usuário',
        email: '',
        total_xp: 0,
        nivel: '--',
        xp_proximo_nivel: null,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================================
  // FUNÇÃO AUXILIAR: getImagemFallback
  // Retorna a imagem local correspondente ao nome do hábito
  // Usado quando o backend não fornece uma URL de ícone
  // ============================================================
  const getImagemFallback = (label: string) => {
    const map: Record<string, any> = {
      'Musculação': imgMusculacao,
      'Leitura': imgLeitura,
      'Beber Água': imgAgua,
      'Corrida': imgCorrendo,
      'Correr': imgCorrendo,
    };
    return map[label] || imgMusculacao; // fallback padrão
  };

  // ============================================================
  // FUNÇÃO: atualizarDadosPessoais
  // Envia para o backend os novos dados (peso, altura, data_nasc)
  // ============================================================
  const atualizarDadosPessoais = async (
    data_nascimento: string,
    peso: string,
    altura: string
  ) => {
    try {
      setIsLoading(true);
      
      // Faz a requisição PUT para o backend
      await api.put('/usuarios/dados-pessoais', {
        data_nascimento: data_nascimento || null,
        peso: peso ? parseFloat(peso) : null,
        altura: altura ? parseFloat(altura) : null,
      });
      
      // Recarrega todos os dados para refletir as mudanças
      await carregarDados();
      
      Alert.alert('Sucesso', 'Dados pessoais atualizados!');
      return true;
    } catch (error: any) {
      Alert.alert('Erro', 'Não foi possível atualizar os dados.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================================
  // FUNÇÃO: atualizarPerfil (editar nome e avatar)
  // Placeholder – ainda precisa implementar upload de imagem
  // ============================================================
  const atualizarPerfil = async (nome: string, avatarBase64?: string) => {
    try {
      setIsLoading(true);
      // Aqui seria implementado o upload da imagem
      // O endpoint PUT /usuarios/:id já suporta upload via FormData
      Alert.alert('Em breve', 'Edição de perfil será implementada em breve.');
      return false;
    } catch (error) {
      Alert.alert('Erro', 'Não foi possível atualizar o perfil.');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  // ============================================================
  // LÓGICA DAS CONQUISTAS (baseada no nível atual)
  // ============================================================
  // Lista de conquistas com o nível mínimo necessário para desbloquear
  const conquistas = [
    { title: '10 Dias', icon: imgDezDias, nivelMinimo: 'Aprendiz' },
    { title: '50 Dias', icon: imgCinquentaDias, nivelMinimo: 'Praticante' },
    { title: '100 Dias', icon: imgCemDias, nivelMinimo: 'Dedicado' },
  ];

  // Ordem dos níveis (quanto maior o XP, mais avançado)
  const niveisOrdenados = ['Iniciante', 'Aprendiz', 'Praticante', 'Dedicado', 'Mestre', 'Lendário'];

  // Filtra apenas as conquistas cujo nível mínimo já foi alcançado
  const conquistasDesbloqueadas = conquistas.filter((c) => {
    const nivelAtualIndex = niveisOrdenados.indexOf(perfil?.nivel || 'Iniciante');
    const nivelMinimoIndex = niveisOrdenados.indexOf(c.nivelMinimo);
    return nivelAtualIndex >= nivelMinimoIndex;
  });

  // ============================================================
  // FORMATAÇÃO DOS DADOS PESSOAIS PARA EXIBIÇÃO
  // ============================================================
  // Função que calcula a idade a partir da data de nascimento
  function calcularIdade(dataNasc: string) {
    if (!dataNasc) return '--';
    const nasc = new Date(dataNasc);
    const hoje = new Date();
    let idade = hoje.getFullYear() - nasc.getFullYear();
    const mes = hoje.getMonth() - nasc.getMonth();
    // Ajusta se ainda não fez aniversário este ano
    if (mes < 0 || (mes === 0 && hoje.getDate() < nasc.getDate())) {
      idade--;
    }
    return `${idade} anos`;
  }

  // Array com os dados pessoais formatados para a view
  const personalData = [
    { label: 'Data de Nascimento', value: dadosPessoais.data_nascimento || 'Não definida' },
    { label: 'Idade', value: dadosPessoais.data_nascimento ? calcularIdade(dadosPessoais.data_nascimento) : '--' },
    { label: 'Peso', value: dadosPessoais.peso ? `${dadosPessoais.peso} kg` : '--' },
    { label: 'Altura', value: dadosPessoais.altura ? `${dadosPessoais.altura} m` : '--' },
  ];

  // ============================================================
  // CONTROLE DO MODAL DE EDIÇÃO DE PERFIL
  // ============================================================
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [editNome, setEditNome] = useState('');
  const [editAvatar, setEditAvatar] = useState<string | null>(null);

  const handleEditProfile = () => {
    setEditNome(perfil?.nome || '');
    setEditAvatar(perfil?.avatar_url || null);
    setEditModalVisible(true);
  };

  const salvarEdicaoPerfil = async () => {
    // Placeholder – implementar posteriormente
    Alert.alert('Em breve', 'Edição de perfil será implementada.');
  };

  // ============================================================
  // CARREGAR OS DADOS AO MONTAR O COMPONENTE
  // ============================================================
  useEffect(() => {
    carregarDados();
  }, []);

  // ============================================================
  // RETORNO DO HOOK (tudo o que a view precisa)
  // ============================================================
  return {
    // Dados principais
    perfil,
    dadosPessoais,
    habitosRecentes: habitosRecentes.length > 0 
      ? habitosRecentes 
      : [ // Fallback com dados mockados, caso não haja hábitos
          { id: 1, label: 'Musculação', image: imgMusculacao },
          { id: 2, label: 'Leitura', image: imgLeitura },
          { id: 3, label: 'Beber Água', image: imgAgua },
          { id: 4, label: 'Correr', image: imgCorrendo },
        ],
    isLoading,
    error,
    personalData,
    conquistasDesbloqueadas,
    
    // Funções de ação
    handleEditProfile,
    atualizarDadosPessoais,
    editModalVisible,
    setEditModalVisible,
    editNome,
    setEditNome,
    editAvatar,
    setEditAvatar,
    salvarEdicaoPerfil,
  };
};