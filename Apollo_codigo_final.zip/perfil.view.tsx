// ============================================================
// IMPORTAÇÕES
// ============================================================

import React from 'react';
import {
  View,
  Text,
  Image,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  TextInput,
} from 'react-native';
import { styles } from './perfil.styles';
import { Header } from '../../components/Header';
import { usePerfil } from './usePerfil';

// Imagem de fallback para o avatar
// @ts-ignore
import imgPerfil from '../../../assets/imagemExemploPerfil.png';

// ============================================================
// COMPONENTE PRINCIPAL: ProfileView
// ============================================================
export default function ProfileView() {
  // Extrai todos os dados e funções do hook
  const {
    perfil,
    isLoading,
    error,
    personalData,
    conquistasDesbloqueadas,
    habitosRecentes,
    handleEditProfile,
    editModalVisible,
    setEditModalVisible,
    editNome,
    setEditNome,
  } = usePerfil();

  // ---- TELA DE CARREGAMENTO ----
  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
          <ActivityIndicator size="large" color="#6200ee" />
        </View>
      </SafeAreaView>
    );
  }

  // ---- TELA DE ERRO ----
  if (error) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
          <Text style={{ color: 'red', textAlign: 'center' }}>{error}</Text>
          <TouchableOpacity onPress={() => {}} style={{ marginTop: 20 }}>
            <Text style={{ color: '#6200ee' }}>Tentar novamente</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ---- BARRA DE PROGRESSO ----
  const xpPercentage = perfil && perfil.xp_proximo_nivel
    ? `${(perfil.total_xp / perfil.xp_proximo_nivel) * 100}%` as import('react-native').DimensionValue
    : '0%';

  // ============================================================
  // RENDERIZAÇÃO DA INTERFACE
  // ============================================================

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
        
        {/* HEADER – componente reutilizável */}
        <View style={{ paddingHorizontal: 20 }}>
          <Header />
        </View>

        {/* ============================================================
            SEÇÃO: AVATAR, NOME E BARRA DE XP
            ============================================================ */}
        <View style={styles.headerContainer}>
          <View style={styles.avatarContainer}>
            <Image
              source={perfil?.avatar_url ? { uri: perfil.avatar_url } : imgPerfil}
              style={styles.avatar}
            />
          </View>

          <Text style={styles.name}>{perfil?.nome || 'Usuário'}</Text>
          <Text style={styles.email}>{perfil?.email || ''}</Text>

          {/* Barra de Progresso do Nível */}
          <View style={styles.levelContainer}>
            <Text style={styles.levelText}>Nível {perfil?.nivel || 'Iniciante'}</Text>
            <View style={styles.progressBarBackground}>
              <View style={[styles.progressBarFill, { width: xpPercentage }]} />
            </View>
            <Text style={styles.xpText}>
              {perfil?.total_xp ?? 0} XP
              {perfil?.xp_proximo_nivel ? ` / ${perfil.xp_proximo_nivel} XP` : ''}
            </Text>
          </View>

          {/* Botão para abrir o modal de edição de perfil */}
          <TouchableOpacity style={styles.editButton} onPress={handleEditProfile}>
            <Text style={styles.editButtonText}>Editar Perfil</Text>
          </TouchableOpacity>
        </View>

        {/* ============================================================
            CARTÃO 1: DADOS PESSOAIS (agora com dados reais)
            ============================================================ */}
        <View style={styles.mainCard}>
          <Text style={styles.cardTitle}>Dados Pessoais</Text>
          <View style={styles.dataGrid}>
            {personalData.map((item, index) => (
              <View key={index} style={styles.dataItem}>
                <Text style={styles.dataLabel}>{item.label}</Text>
                <Text style={styles.dataValue}>{item.value}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ============================================================
            CARTÃO 2: CONQUISTAS (apenas as desbloqueadas)
            ============================================================ */}
        <View style={styles.mainCard}>
          <Text style={styles.cardTitle}>Conquistas</Text>
          <View style={styles.achievementsGrid}>
            {conquistasDesbloqueadas.length > 0 ? (
              conquistasDesbloqueadas.map((item, index) => (
                <View key={index} style={{ alignItems: 'center', marginRight: 20, marginBottom: 10 }}>
                  <Image source={item.icon} style={styles.achievementIcon} resizeMode="contain" />
                  <Text style={{ fontSize: 12, fontWeight: 'bold', color: '#4B5563' }}>{item.title}</Text>
                </View>
              ))
            ) : (
              <Text style={{ color: '#6B7280', textAlign: 'center' }}>
                Continue completando hábitos para desbloquear conquistas!
              </Text>
            )}
          </View>
        </View>

        {/* ============================================================
            CARTÃO 3: MEUS HÁBITOS (últimos 4 registrados)
            ============================================================ */}
        <View style={styles.mainCard}>
          <Text style={styles.cardTitle}>Meus Hábitos</Text>
          <View style={styles.habitsGrid}>
            {habitosRecentes.map((habit, index) => (
              <View key={index} style={styles.habitItem}>
                <Image
                  source={habit.image ? { uri: habit.image } : require('../../../assets/musculacao.png')}
                  style={styles.habitImage}
                  resizeMode="contain"
                />
                <Text style={styles.habitLabel}>{habit.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* ============================================================
            MODAL DE EDIÇÃO DE PERFIL (simples, sem upload de avatar)
            ============================================================ */}
        <Modal
          visible={editModalVisible}
          animationType="slide"
          transparent={true}
          onRequestClose={() => setEditModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Editar Perfil</Text>
              
              {/* Campo para editar o nome */}
              <TextInput
                style={styles.modalInput}
                value={editNome}
                onChangeText={setEditNome}
                placeholder="Nome"
                placeholderTextColor="#9CA3AF"
              />
              
              {/* Aqui futuramente virá o seletor de avatar */}

              {/* Botões de ação */}
              <View style={styles.modalButtons}>
                <TouchableOpacity
                  style={[styles.modalButton, styles.modalButtonCancel]}
                  onPress={() => setEditModalVisible(false)}
                >
                  <Text style={[styles.modalButtonText, { color: '#374151' }]}>Cancelar</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.modalButton, styles.modalButtonSave]}
                  onPress={() => {
                    // Salvar alterações
                    setEditModalVisible(false);
                  }}
                >
                  <Text style={styles.modalButtonText}>Salvar</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>

      </ScrollView>
    </SafeAreaView>
  );
}