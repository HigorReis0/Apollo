const express = require("express");
const routes = express.Router();

// 1. IMPORTAÇÕES
const usuarioController = require("../controllers/usuarioController");
const upload = require("../config/multer");
const authMiddleware = require("../middlewares/auth");

// ============================================================
// ROTAS PÚBLICAS (sem autenticação)
// ============================================================
routes.post("/", upload.single("avatar"), usuarioController.criar);
routes.post("/login", usuarioController.login);
routes.post("/login-google", usuarioController.loginGoogle);

// ============================================================
// ROTAS PRIVADAS (com autenticação)
// ============================================================

// ---- Perfil e dados básicos ----
routes.get("/perfil", authMiddleware, usuarioController.perfil);
routes.get("/", authMiddleware, usuarioController.listar);
routes.get("/:id", authMiddleware, usuarioController.buscarPorId);
routes.put("/:id", authMiddleware, upload.single("avatar"), usuarioController.atualizar);
routes.delete("/:id", authMiddleware, usuarioController.deletar);

// ---- NOVAS ROTAS PARA O PERFIL ----

// Atualizar dados pessoais (peso, altura, data de nascimento)
routes.put("/dados-pessoais", authMiddleware, usuarioController.atualizarDadosPessoais);

// Buscar últimos 4 hábitos registrados pelo usuário
routes.get("/habitos-recentes", authMiddleware, usuarioController.habitosRecentes);

module.exports = routes;