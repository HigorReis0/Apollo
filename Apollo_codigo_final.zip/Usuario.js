// ============================================================
// IMPORTAÇÕES
// ============================================================

// Importa a classe DataTypes para definir os tipos das colunas
const { DataTypes } = require("sequelize");

// Importa a conexão com o banco de dados
const sequelize = require("../config/database");

// ============================================================
// DEFINIÇÃO DO MODELO "Usuario"
// Representa a tabela 'tab_usuario' no PostgreSQL
// ============================================================
const Usuario = sequelize.define(
  "Usuario", // Nome interno do modelo no Sequelize
  {
    // ---- Chave Primária ----
    usuario_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      field: 'usuario_id' // Nome exato da coluna no banco
    },

    // ---- Nome do usuário (obrigatório) ----
    nome: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },

    // ---- E-mail (obrigatório e único) ----
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },

    // ---- Senha (pode ser nula para login com Google) ----
    senha: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },

    // ---- ID do Google (opcional, para login social) ----
    google_id: {
      type: DataTypes.STRING(255),
      unique: true,
      allowNull: true,
    },

    // ---- URL da foto de perfil (opcional) ----
    avatar_url: {
      type: DataTypes.TEXT,
      allowNull: true,
    },

    // ============================================================
    // NOVOS CAMPOS – DADOS PESSOAIS (adicionados agora)
    // ============================================================

    // Data de nascimento (formato DATE, ex: '1995-04-15')
    data_nascimento: {
      type: DataTypes.DATEONLY, // Apenas data, sem hora
      allowNull: true,
      field: 'data_nascimento'
    },

    // Peso em kg (ex: 62.5)
    peso: {
      type: DataTypes.DECIMAL(5, 2), // 5 dígitos no total, 2 casas decimais
      allowNull: true,
      field: 'peso'
    },

    // Altura em metros (ex: 1.68)
    altura: {
      type: DataTypes.DECIMAL(5, 2),
      allowNull: true,
      field: 'altura'
    }
  },
  {
    // ---- CONFIGURAÇÕES ADICIONAIS ----
    tableName: "tab_usuario",    // Nome exato da tabela no banco
    timestamps: false,           // Não usamos createdAt/updatedAt
  }
);

// Exporta o modelo para ser usado nos controllers
module.exports = Usuario;